﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
namespace DAL
{
    public class StudentsDal
    {
        public static List<Student>  GetAll()
        {
            List<Student> st1 = new List<Student>
          {
                new Student(1,"onkar",34),
                new Student(2,"sagar",12),
                new Student(3,"gani",78),
                new Student(4,"rahul",22),
                new Student(5,"supriya",04),
          };
            return st1;
        }
       
    

    }
}
