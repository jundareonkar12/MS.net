﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FirstTest.Models
{
    public class Test
    {
        public string Name { get; set; }
    }
}