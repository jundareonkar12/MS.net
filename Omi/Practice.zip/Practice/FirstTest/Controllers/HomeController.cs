﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FirstTest.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
       public class Test
        {
            public string Name { get; set;}
        }
        public ActionResult Index()
        {
            Test t1 = new Test();
            t1.Name = "Onkar";
            int num = 45;
            this.ViewData["number"] = num;//for primitiv typed typecastng not required
            this.ViewData["testclass"] = t1;

            return View();
        }
    }
}