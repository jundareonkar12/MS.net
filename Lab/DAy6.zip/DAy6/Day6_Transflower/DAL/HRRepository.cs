﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BOL;
namespace DAL
{
    public static class EmployeeDAL
    {
        public static List<Employee> GetAll()
        {
            List<Employee> employees = new List<Employee>();
            string cmdText = "SELECT * FROM Employee";
            //string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\TFLGreenhouse.mdf;Integrated Security=True";

            string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\MS.NET_129_131\Lab\DAy6\Day6_Transflower\Transflower\App_Data\TFLGreenHouse.mdf;Integrated Security=True";
            IDbConnection con = new SqlConnection();
            con.ConnectionString = conString;
            IDbCommand cmd = new SqlCommand(cmdText, con as SqlConnection);
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();//exc query
                while(reader.Read())
                {
                    Employee emp = new Employee();
                    emp.Id = int.Parse(reader["Id"].ToString());
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["LastName"].ToString();
                    emp.ContactNumber = reader["ContactNumber"].ToString();
                    emp.Email = reader["Email"].ToString();
                    emp.City = reader["City"].ToString();

                    employees.Add(emp);
                }
                reader.Close();
            }
            catch (SqlException exp)
            {
                throw exp; 
            }
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return employees;
        }
        public static Employee Get(int id)
        {
            Employee emp = new Employee();
            string cmdText = "SELECT * FROM Employee where Id="+id;
            //string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\TFLGreenhouse.mdf;Integrated Security=True";

            string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\MS.NET_129_131\Lab\DAy6\Day6_Transflower\Transflower\App_Data\TFLGreenHouse.mdf;Integrated Security=True";
            IDbConnection con = new SqlConnection();
            con.ConnectionString = conString;
            IDbCommand cmd = new SqlCommand(cmdText, con as SqlConnection);
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();//exc query
                while (reader.Read())
                {
                    
                    emp.Id = int.Parse(reader["Id"].ToString());
                    emp.FirstName = reader["FirstName"].ToString();
                    emp.LastName = reader["LastName"].ToString();
                    emp.ContactNumber = reader["ContactNumber"].ToString();
                    emp.Email = reader["Email"].ToString();
                    emp.City = reader["City"].ToString();

                                    }
                reader.Close();
            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return emp;
        }
    }
}
