﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ManagerApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void OnFileOpen_Click(object sender, EventArgs e)
        {
            //Deserialization code Snippet
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName = dlg.FileName;
                FileStream fs = new FileStream(fileName, FileMode.Open);
                BinaryFormatter bf = new BinaryFormatter();
                customer = bf.Deserialize(fs) as List<BOL.Customers>;
                fs.Close();
                this.dataGridView1.DataSource = customer;
            }
        }

        private void OnFileSaveAs_Click(object sender, EventArgs e)
        {
            //Serialization code Snippet
            SaveFileDialog dlg = new SaveFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName = dlg.FileName;
                FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, customer);
                fs.Close();
            }
        }

        private void OnFileExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Are you sure you want to exit?","URM", MessageBoxButtons.YesNo);
            this.Close();
        }
        private List<BOL.Customers> customer = new List<BOL.Customers>();

        private void OnEditRefresh_Click(object sender, EventArgs e)
        {
            this.txtFirstName.Text = string.Empty;
            this.txtLastName.Text = string.Empty;
            this.txtEmail.Text = string.Empty;
            this.txtContactNumber.Text = string.Empty;
            this.dtpBirthDate.Value = DateTime.Now;
            this.dataGridView1.DataSource = customer;
        }

        private void OnCustomerRegister_Click(object sender, EventArgs e)
        {
            // Code Snippet for new Customer Registration
            string firstName = this.txtFirstName.Text;
            string lastName = this.txtLastName.Text;
            string email = this.txtEmail.Text;
            string contactNumber = this.txtContactNumber.Text;
            DateTime birthDate = this.dtpBirthDate.Value;

            //Property Initialization Synatax
            BOL.Customers cst = new BOL.Customers
            {
                FirstName = firstName,
                LastName = lastName,
                Email = email,
                ContactNumber = contactNumber,
                BirthDate = birthDate
            };
            //Add newly Created Customer in Generic List collection of Customer
            this.customer.Add(cst);

            //Bind Collection of Customers to Data Grid control
            //using DataSource inbuilt property of Grid
            this.dataGridView1.DataSource = " ";
           this.dataGridView1.DataSource = customer;
            this.txtFirstName.Text=string.Empty;
            this.txtLastName.Text = string.Empty;
            this.txtEmail.Text = string.Empty;
            this.txtContactNumber.Text = string.Empty;
            this.dtpBirthDate.Value = DateTime.Now;

        }
    }
}
