﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransflowerOnline.Models;
namespace TransflowerOnline.Controllers
{
    public class FlowersController : Controller
    {
        // GET: Flowers
        public ActionResult Index()
        {
            List<Product> flowers = new List<Product>();
            flowers.Add(new Product { ID = 11, Title = "Gerbera", Description = "Wedding Flower", UnitPrice = 12, Quantity = 1100 });
            flowers.Add(new Product { ID = 12, Title = "Rose", Description = "Special Flower", UnitPrice = 50, Quantity = 50 });
            flowers.Add(new Product { ID = 13, Title = "Primrose", Description = "Wedding Flower", UnitPrice = 10, Quantity = 650 });
            flowers.Add(new Product { ID = 14, Title = "Sunflower", Description = "Wedding Flower", UnitPrice = 15, Quantity = 800 });
            flowers.Add(new Product { ID = 15, Title = "Frangipani", Description = "Wedding Flower", UnitPrice = 5, Quantity = 700 });
            flowers.Add(new Product { ID = 16, Title = "Jasmine", Description = "Scented Flower", UnitPrice = 20, Quantity = 2000 });
            flowers.Add(new Product { ID = 17, Title = "Lotus", Description = "Festival Flower", UnitPrice = 30, Quantity = 400 });
            flowers.Add(new Product { ID = 18, Title = "Oleander", Description = "Decorational Flower", UnitPrice = 5, Quantity = 5000 });
            flowers.Add(new Product { ID = 19, Title = "Daisy", Description = "Seasonal Flower", UnitPrice = 8, Quantity = 4000 });

            flowers.Add(new Product { ID = 20, Title = "Poppy", Description = "Scented Flower", UnitPrice = 3, Quantity = 5000 });
            this.ViewData["flowers"] = flowers;
            return View();
        }
    }
}