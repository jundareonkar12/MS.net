﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BOL;
namespace BLL
{
    public class AccountManager
    {
        public static bool Validate(string name,string pass)
        {        
            return IdentityDAL.Validate(name,pass);
        }
        public static bool Insert(User u)
        {
            return IdentityDAL.Insert(u);
        }
        public static bool Delete(User u)
        {
            return IdentityDAL.Delete(u);
        }
    }
}
