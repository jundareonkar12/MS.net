﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using BLL;
using BOL;
namespace Transflower.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }
       [HttpPost]
        public ActionResult Login(string Name, string Password)
        {
            if(AccountManager.Validate(Name,Password))
            {
                ViewData["msg"] = "LOGIN SUCESSFULL";
                return RedirectToAction("Index","Employee");
            }

            return View();
        }
        public ActionResult Insert()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Insert(int id,string name,string password)
        {
            User u = new User
            {
                Name = name,
                ID = id,
                Password = password
            };
            if(AccountManager.Insert(u))
            {
                return RedirectToAction("Index", "Employee");
            }

            return View();
        }
        public ActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Delete(int id,string name)
        {
            User u = new User
            {
                Name = name,
                ID = id
                
            };
            if (AccountManager.Delete(u))
            {
                return RedirectToAction("Index", "Employee");
            }

            return View();
        }
    }
}