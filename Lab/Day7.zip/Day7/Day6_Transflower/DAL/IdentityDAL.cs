﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using BOL;

namespace DAL
{
   public static  class IdentityDAL
    {
        public static string conString = string.Empty;
        static IdentityDAL()
        {
            conString = ConfigurationManager.ConnectionStrings["TFLConnection"].ConnectionString;
        }
        public static bool Validate(string name,string pass)
        {
            bool success = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdtext = "select * from users where name=@nm and password=@pass";
            SqlCommand cmd = new SqlCommand(cmdtext, con);
            cmd.Parameters.Add(new SqlParameter("@nm",name));
            cmd.Parameters.Add(new SqlParameter("@pass", pass));
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();
                if(reader.Read())
                {
                    success = true;
                }
            }
            catch(SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return success;
        }
        public static bool DisconnectedValidate(User u)
        {
            bool success = false;
            
            return success;
        }
        public static bool Insert(User u)
        {
            bool success = false;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdtext = "insert into users values(@id,@name,@password)";
            SqlCommand cmd = new SqlCommand(cmdtext, con);
            cmd.Parameters.Add(new SqlParameter("@id", u.ID));
            cmd.Parameters.Add(new SqlParameter("@name", u.Name));
            cmd.Parameters.Add(new SqlParameter("@password",u.Password));
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                success = true;
            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return success;
        }
        public static bool Delete(User u)
        {
            bool success = false;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdtext = "DELETE FROM users WHERE Id=@Id and Name=@Name";
            SqlCommand cmd = new SqlCommand(cmdtext, con);
            cmd.Parameters.Add(new SqlParameter("@id", u.ID));
            cmd.Parameters.Add(new SqlParameter("@name", u.Name));
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                success = true;
            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return success;
        }
    }
   
}
