﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BOL;
namespace BLL
{
   public  class PizzaService
    {
        public static List<PizzaDtls> getAllPizzaDetails()
        {
            return Connection.FetchPizzaDetails();
        }


        public static PizzaDtls getPizza(int id)
        {
            return Connection.getPizzaDetail(id);
        }

        public static bool deletePizza(int id)
        {
            return Admin.DeletePizza(id);
        }

        public static bool updatePizza(PizzaDtls pd)
        {
            return Admin.UpdatePizzaPrice(pd);
        }
    }
}
