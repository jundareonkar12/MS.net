﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BOL
{
    public class User
    {

        public User()
        {
            Console.WriteLine("in user ctor");
        }
        [Required]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        public string Role { get; set; }
    }
}
